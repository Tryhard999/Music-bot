module.exports = {
    app: {
        token: 'OTA5MTQyOTI5MTQxMDM5MTY0.GurL9F.rYTctjtBTOD0dkRTN5LCV7xa3CxG3QktyFI844',
        playing: 'music tryhard',
        global: true,
        guild: '913117738308861973'
    },

    opt: {
        DJ: {
            enabled: false,
            roleName: '',
            commands: []
        },
        maxVol: 100,
        leaveOnEnd: true,
        loopMessage: false,
        spotifyBridge: true,
        defaultvolume: 75,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
};
